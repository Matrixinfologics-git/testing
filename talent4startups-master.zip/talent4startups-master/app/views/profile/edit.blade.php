@extends('layouts.default')

@section('content')
	<div class="row">
		<div class="col-md-6">
				<h1>Profile</h1>
				<h2>About You</h2>

					TODO: Finish Me
			</div>
	</div>
@stop
